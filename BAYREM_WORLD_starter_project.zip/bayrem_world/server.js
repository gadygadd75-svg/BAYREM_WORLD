// Minimal Node.js backend for BAYREM WORLD.
// Keep OPENAI_API_KEY on the server; never place it in browser HTML/JS.
import http from "node:http";
import { readFile } from "node:fs/promises";
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const root = new URL(".", import.meta.url);
const mime = {".html":"text/html; charset=utf-8",".json":"application/json; charset=utf-8",".js":"text/javascript; charset=utf-8"};
function send(res,status,body,type="application/json; charset=utf-8"){res.writeHead(status,{"Content-Type":type,"X-Content-Type-Options":"nosniff"});res.end(body)}
http.createServer(async(req,res)=>{
  const url = new URL(req.url,"http://localhost");
  if(req.method==="POST" && url.pathname==="/api/chat"){
    if(!API_KEY) return send(res,503,JSON.stringify({error:"Server admin must configure OPENAI_API_KEY"}));
    let raw=""; for await(const chunk of req) raw+=chunk;
    let message=""; try { message=JSON.parse(raw).message?.toString().slice(0,4000)||""; } catch {}
    if(!message.trim()) return send(res,400,JSON.stringify({error:"Message is required"}));
    try {
      const response=await fetch("https://api.openai.com/v1/responses",{
        method:"POST",headers:{"Authorization":`Bearer ${API_KEY}`,"Content-Type":"application/json"},
        body:JSON.stringify({model:MODEL,instructions:"You are BAYREM WORLD, a helpful assistant. Reply in the user's language, and use Tunisian Arabic when appropriate. Give safe, practical advice about gaming and content creation.",input:message})
      });
      const data=await response.json();
      if(!response.ok) return send(res,response.status,JSON.stringify({error:data.error?.message||"AI request failed"}));
      const reply=data.output?.flatMap(x=>x.content||[]).filter(x=>x.type==="output_text").map(x=>x.text).join("\n")||"ما نجمتش نكوّن رد.";
      return send(res,200,JSON.stringify({reply}));
    } catch { return send(res,502,JSON.stringify({error:"Could not reach AI service"})); }
  }
  let path=url.pathname==="/" ? "/index.html" : url.pathname;
  if(path.includes("..")) return send(res,400,"Bad path","text/plain");
  try { const ext=path.slice(path.lastIndexOf(".")); const content=await readFile(new URL("."+path,root)); send(res,200,content,mime[ext]||"application/octet-stream"); }
  catch { send(res,404,"Not found","text/plain; charset=utf-8"); }
}).listen(PORT,()=>console.log(`BAYREM WORLD running on port ${PORT}`));
