const CACHE='bayrem-world-v1';
const ASSETS=['/','/index.html','/manifest.json'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET' || new URL(e.request.url).pathname.startsWith('/api/')) return;
 e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).catch(()=>caches.match('/index.html'))));
});