# BAYREM WORLD — starter project

This project contains:
- Arabic/Tunisian-friendly mobile web interface
- Gaming tips for Free Fire, eFootball, Naruto PSP, and Gangstar Mirage City
- Creator-content idea generator
- Optional server-side OpenAI Responses API integration
- PWA manifest and service worker for installable web-app behavior

## Run locally
1. Install Node.js 18 or newer on a computer or hosting environment.
2. In this folder, set `OPENAI_API_KEY` as an environment variable. Optional: set `OPENAI_MODEL`.
3. Run `npm start`.
4. Open `http://localhost:3000`.

Do not put your API key in `index.html`, and do not share it publicly. API usage may incur charges depending on your account and model.

## Android
The web app can be installed from a supported browser after deployment over HTTPS: open the website, use the browser menu, and choose “Install app” or “Add to Home screen” (wording varies).
This package is not an APK. Building a signed APK requires an Android wrapper/build process such as Capacitor and an Android build environment. The included PWA is the simplest first step for a phone-only workflow.

## Deploy
Deploy to a Node.js host that supports server routes and environment variables. Configure `OPENAI_API_KEY` in the host's private environment settings. Use HTTPS.
